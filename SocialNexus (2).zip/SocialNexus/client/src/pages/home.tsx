import React from 'react';
import ForumLayout from '@/components/forum/ForumLayout';

export default function Home() {
  return <ForumLayout />;
}
